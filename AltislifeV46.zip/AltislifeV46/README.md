# BOARDS

1. **Backlog** - Newly created
2. **ToDo** - To do first
3. **InProgress** - Working on
4. **Waiting** - Waiting for upload to server
5. **Testing** - Uploaded to server for testing
6. **Done** - Tested, seems to work
7. **Closed** - If working u can close after a week

# RELEASES TAGS
When version is complete you can upload pbo file to [RELEASES branch](https://gitlab.com/doodzio/RGroleplay6.altis/tree/RELEASES) and add [tag](https://gitlab.com/doodzio/RGroleplay6.altis/tags) with link to this file
tag example 
```
[Version 29 pbo]( https://gitlab.com/doodzio/RGroleplay6.altis/blob/RELEASES/altis_life29.Altis.pbo)
```

# MASTER branch
Points to current version

# VERSION BRANCH 
Points to closed version or to working snapshot
ss